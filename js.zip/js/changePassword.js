function changePass()
{
	var scur_pass = $("#Password").val();
	var scpassword = $("#NewPassword").val();
	var spassword = $("#NewConfirmPassowrd").val();
	$.post("changePassword.php",{currPass:Password,newPass:NewPassword,confPass:NewConfirmPassword},function(data){
		if(data == "success")
		{
			alert("Password has been changed!");
			location.href = "user.php";
		}
		else if(data == "reconnect")
		{
			alert("Please fill up all the fields!");
		}
		else if(data == "notSame")
		{
			alert("New password doesn't match to confirmation!");
			$("#NewConfirmPassword").val("");
			$("#NewPassword").val("");
		}
		else if(data == "wrongDetail")
		{
			alert("Current password doesn't match to your account!");
		}
	});
}